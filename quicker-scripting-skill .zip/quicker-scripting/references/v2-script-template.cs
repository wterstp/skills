// Quicker V2「脚本动作」示例: 清理剪贴板
// 用法: 新建动作 → 选“Quicker脚本动作” → 标题填“清理剪贴板” →
// 把编辑器里的模板替换成这段 → 保存后运行(F5)。
// 注意: 保存源码和运行是两个操作; 运行会真的覆盖剪贴板内容, 先复制一段
// " 你好 " 这样的带空格文本再试, 跑完看首尾空格是不是没了。
string Main()
{
    var text = qk.Clipboard.GetText();
    if (text == null)
    {
        qk.Ui.Notify("剪贴板中没有文本");
        return "";
    }
    var result = text.Trim();
    qk.Clipboard.SetText(result);
    qk.Ui.Notify("已清理剪贴板");
    return result;
}
