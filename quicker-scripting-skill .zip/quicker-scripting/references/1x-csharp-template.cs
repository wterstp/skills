// Quicker 1.x「运行 C# 代码」模块最小模板
// 用法: 新建组合动作, 加一个「运行 C# 代码」模块, 把本文件全部内容粘贴进。
// 模块设置: 运行模式「普通模式 v2」(没有时用 v1); 执行线程「后台线程」;
// 「允许缓存程序集」开; 「失败后停止」开。
// 演示: 读变量 Input, 弹一个小窗口显示并可编辑, 关闭后把结果写进变量 Output。
// 模板里只有一个顶层 Exec 函数, 同一个文件里可以再加自己的类和方法。
using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

// Quicker 将会调用的函数
public static void Exec(Quicker.Public.IStepContext context)
{
object v = null;
try { v = context.GetVarValue("Input");} catch {}
string input = v == null? "": v.ToString();

string output = "";
Thread uiThread = new Thread(delegate()
{
Form f = new Form();
f.Text = "Quicker 模板";
f.Size = new Size(320, 180);
f.StartPosition = FormStartPosition.CenterScreen;

TextBox t = new TextBox();
t.Text = input;
t.Dock = DockStyle.Fill;
t.Multiline = true;
f.Controls.Add(t);

Button b = new Button();
b.Text = "确定";
b.Dock = DockStyle.Bottom;
b.Click += delegate { output = t.Text; f.Close();};
f.Controls.Add(b);

Application.Run(f);
});
uiThread.SetApartmentState(ApartmentState.STA);
uiThread.Start();
uiThread.Join();

try { context.SetVarValue("Output", output);} catch {}
}
